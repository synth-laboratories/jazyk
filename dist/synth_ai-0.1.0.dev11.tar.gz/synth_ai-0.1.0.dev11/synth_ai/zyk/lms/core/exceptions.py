from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Literal, Optional, Union


class StructuredOutputCoercionFailureException(Exception):
    pass


# ... rest of imports ...
