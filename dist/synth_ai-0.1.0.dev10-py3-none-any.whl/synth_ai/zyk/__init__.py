from synth_ai.zyk.lms.core.main import LM

__all__ = ["LM"]
