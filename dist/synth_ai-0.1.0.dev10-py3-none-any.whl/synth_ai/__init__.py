"""
Synth AI - Software for aiding the best and multiplying the will.
"""

from importlib.metadata import version


__version__ = version("synth-ai")  # Gets version from installed package metadata
